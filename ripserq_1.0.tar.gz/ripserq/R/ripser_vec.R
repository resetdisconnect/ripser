#' @export
#' ripser_vec <- function(dataset, dim, thresh, ratio, p) {
#'  .Call('_ripserq_ripser_vec', PACKAGE = 'ripserq', dataset, as.integer(dim), as.numeric(thresh), as.numeric(ratio), as.integer(p))
#' }
